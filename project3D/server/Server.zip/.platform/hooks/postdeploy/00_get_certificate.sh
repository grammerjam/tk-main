#!/usr/bin/env bash
sudo certbot -n -d www.P3D-SM-NodeServer.us-east-1.elasticbeanstalk.com --nginx --agree-tos --email stackmonstersgrammerhub@gmail.com